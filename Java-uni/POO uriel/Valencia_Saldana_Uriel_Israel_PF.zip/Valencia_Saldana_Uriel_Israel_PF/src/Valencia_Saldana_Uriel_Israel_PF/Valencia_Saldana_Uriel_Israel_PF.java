package Valencia_Saldana_Uriel_Israel_PF;

import javax.swing.JFrame;

public class Valencia_Saldana_Uriel_Israel_PF {

    public static void main(String[] args) {
        Interfaz_Inicio inicio = new Interfaz_Inicio();
        
        inicio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        inicio.setBounds(320, 120, 750, 550);
        inicio.setVisible(true);
    }
    
}
