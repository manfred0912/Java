package Valencia_Saldana_Uriel_Israel_T10;

import javax.swing.JFrame;

public class Valencia_Saldana_Uriel_Israel_T10 {
   
    public static void main(String[] args) {
        TextEditor et = new TextEditor();
        
        et.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        et.setSize(450, 200);
        
        et.setVisible(true);    
    }
    
}
